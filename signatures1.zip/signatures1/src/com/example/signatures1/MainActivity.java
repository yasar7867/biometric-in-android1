package com.example.signatures1;

import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;

import android.os.Bundle;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.hardware.Camera;
import android.hardware.Camera.Face;
import android.hardware.Camera.FaceDetectionListener;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.Toast;

public class MainActivity extends Activity implements OnClickListener{
LinearLayout v;
public Button reg,clr;
public Camera mCamera;
Timer r=new Timer();
public static int historySize;
public static float findx[]=new float[10000];
public static float findy[]=new float[10000];
SignatureView sv;
CameraPreview mPreview;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        v=(LinearLayout)findViewById(R.id.imageView1);
        reg=(Button)findViewById(R.id.button11);
        clr=(Button)findViewById(R.id.button2);
        clr.setOnClickListener(this);
        reg.setOnClickListener(this);
        mCamera=Camera.open(1);
        mCamera.setDisplayOrientation(90);
        mPreview = new CameraPreview ( this , mCamera ) ;
        LinearLayout preview=(LinearLayout )this.findViewById (R.id.imageView5);
        preview.addView (this.mPreview );
        this.sv=new SignatureView(this);
        v.addView(sv);
       
        
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
    
    	 switch (item.getItemId()) {
    	    case R.id.item1:
    	    	Intent ii2=new Intent(MainActivity.this,MainActivity2.class);
    	    	startActivity(ii2);
    	    	finish();
    	        return true;
    	    default:
    	        return super.onOptionsItemSelected(item);
    	 }
    }

	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
		switch(arg0.getId())
		{
		case R.id.button2:
        	
			this.sv.clearSignature();
			
			
 break;
		case R.id.button11:
	        mCamera.startFaceDetection();
	        reg.setEnabled(false);
			check();
			break;
 default:
	 break;
}
		}
 void check()
	{
	SQLiteDatabase db=this.openOrCreateDatabase("mydb.db",MODE_PRIVATE, null);
    db.execSQL("CREATE TABLE IF NOT EXISTS yas(fx float,fy float);");
    Cursor cc;
    int count12 = 0;
   /* try
    {
    cc=db.rawQuery("select fx,fy from yas",null);
    Toast.makeText(MainActivity.this,"table"+cc.getFloat(0)+cc.getFloat(1), Toast.LENGTH_LONG).show();
    int count12=0;
	Toast.makeText(MainActivity.this,historySize , Toast.LENGTH_LONG).show();
    if(cc.isAfterLast()==false)
    {   
    	for(int i=0;i<historySize;i++)
		
		{
			if(findx[i]==cc.getFloat(0)&&findy[i]==cc.getFloat(1))
			{
				count12++;
			
			}
			Toast.makeText(MainActivity.this, "data available",Toast.LENGTH_LONG).show();
			cc.moveToNext();
		}
		count12=(count12/historySize)*100;
    }
		if(count12>30)
			Toast.makeText(MainActivity.this, "successfull login"+count12, Toast.LENGTH_LONG).show();
		else
			Toast.makeText(MainActivity.this, "failed"+count12, Toast.LENGTH_LONG).show();

		Toast.makeText(MainActivity.this, "successfull login"+count12, Toast.LENGTH_LONG).show();
		Intent i =new Intent(MainActivity.this,SecondActivity.class);
    }
    catch(Exception e)
    {
    	
    }*/
    for(int i=0;i<historySize;i++)
    {
    	if(findx[i]<=1&&findy[i]<=1)
    		count12++;
    }
    Toast.makeText(MainActivity.this, "verified your face and signature", 2000).show();
    if((count12/historySize)*100>40)
    r.schedule(new TimerTask()
    {
    
    
		@Override
		public void run() {
			// TODO Auto-generated method stub
			Intent i =new Intent(MainActivity.this,SecondActivity.class);
	    	startActivity(i);
	    	finish();
		}}, 4000);
	
	}
 public class CameraPreview extends SurfaceView
  implements SurfaceHolder.Callback ,FaceDetectionListener{
 private SurfaceHolder mHolder ;
 private Camera mCamera ;
 RectF rect=new RectF();
 Matrix matrix=new Matrix();
 public CameraPreview ( Context context , Camera camera ) {
  super (context);
 
 this.mCamera=camera;
 this.mHolder = this.getHolder( ) ;
 this.mHolder.addCallback(this ) ;
 this.mHolder.setType (SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS ) ;
 this.mCamera.setFaceDetectionListener(this);
  }
 @Override
 public void surfaceCreated(SurfaceHolder holder) {
try{
 this.mCamera.setPreviewDisplay(holder) ;
 this.mCamera.startPreview( ) ;
}catch(IOException e){
 } }
@Override
public void surfaceChanged(SurfaceHolder arg0, int arg1, int arg2, int arg3) {
	// TODO Auto-generated method stub
	
}
@Override
public void surfaceDestroyed(SurfaceHolder arg0) {
	// TODO Auto-generated method stub
	mCamera.release();
	mCamera=null;
}
@Override
public void onFaceDetection(Face[] arg0, Camera arg1) {
	// TODO Auto-generated method stub
	
}
 }}
 
class SignatureView extends View {
	 
    // set the stroke width
    private static final float STROKE_WIDTH = 5f;
    private static final float HALF_STROKE_WIDTH = STROKE_WIDTH / 2;

    private Paint paint = new Paint();
    private Path path = new Path();

    private float lastTouchX;
    private float lastTouchY;
    private final RectF dirtyRect = new RectF();

    public SignatureView(Context context) {

        super(context);

        paint.setAntiAlias(true);
        paint.setColor(Color.BLACK);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeJoin(Paint.Join.ROUND);
        paint.setStrokeWidth(STROKE_WIDTH);

        // set the bg color as white
        this.setBackgroundColor(Color.WHITE);

        // width and height should cover the screen
        this.setLayoutParams(new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));

    }
    void clearSignature() {
        this.invalidate();
        this.path=new Path();
    }

    /**
     * Get signature
     *
     * @return
     */
    protected Bitmap getSignature() {

        Bitmap signatureBitmap = null;

        // set the signature bitmap
        if (signatureBitmap == null) {
            signatureBitmap = Bitmap.createBitmap(this.getWidth(), this.getHeight(), Bitmap.Config.RGB_565);
        }

        // important for saving signature
        final Canvas canvas = new Canvas(signatureBitmap);
        this.draw(canvas);
        return signatureBitmap;
    }

    /**
     * clear signature canvas
     */
  

    // all touch events during the drawing
    @Override
    protected void onDraw(Canvas canvas) {
        canvas.drawPath(this.path, this.paint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float eventX = event.getX();
        float eventY = event.getY();

        switch (event.getAction()) {
        case MotionEvent.ACTION_DOWN:

            path.moveTo(eventX, eventY);

            lastTouchX = eventX;
            lastTouchY = eventY;
            return true;

        case MotionEvent.ACTION_MOVE:

        case MotionEvent.ACTION_UP:

            resetDirtyRect(eventX, eventY);
            MainActivity.historySize = event.getHistorySize();
            for (int i = 0; i <  MainActivity.historySize-1; i++) {
                float historicalX = event.getHistoricalX(i);
                float historicalY = event.getHistoricalY(i);
                if(i< MainActivity.historySize)
                {
                	 MainActivity.findx[i]=historicalX-event.getHistoricalX(i+1);
                	 MainActivity.findy[i]=historicalY-event.getHistoricalY(i+1);
                }
                expandDirtyRect(historicalX, historicalY);
                path.lineTo(historicalX, historicalY);
            }
            path.lineTo(eventX, eventY);
            break;

        default:

            return false;
        }

        invalidate((int) (dirtyRect.left - HALF_STROKE_WIDTH),
                (int) (dirtyRect.top - HALF_STROKE_WIDTH),
                (int) (dirtyRect.right + HALF_STROKE_WIDTH),
                (int) (dirtyRect.bottom + HALF_STROKE_WIDTH));

        lastTouchX = eventX;
        lastTouchY = eventY;

        return true;
    }

    private void expandDirtyRect(float historicalX, float historicalY) {
        if (historicalX < dirtyRect.left) {
            dirtyRect.left = historicalX;
        } else if (historicalX > dirtyRect.right) {
            dirtyRect.right = historicalX;
        }

        if (historicalY < dirtyRect.top) {
            dirtyRect.top = historicalY;
        } else if (historicalY > dirtyRect.bottom) {
            dirtyRect.bottom = historicalY;
        }
    }

    private void resetDirtyRect(float eventX, float eventY) {
        dirtyRect.left = Math.min(lastTouchX, eventX);
        dirtyRect.right = Math.max(lastTouchX, eventX);
        dirtyRect.top = Math.min(lastTouchY, eventY);
        dirtyRect.bottom = Math.max(lastTouchY, eventY);
    }

}


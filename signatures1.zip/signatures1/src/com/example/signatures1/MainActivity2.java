package com.example.signatures1;

import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.Toast;

public class MainActivity2 extends Activity implements OnClickListener{
LinearLayout v;
Button reg,clr,vi;
public static int historySize=0;
public static int findx[]=new int[10000];
public static int findy[]=new int[10000];
SignatureView sv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_activity2);
        v=(LinearLayout)findViewById(R.id.imageView2);
        reg=(Button)findViewById(R.id.but);
        clr=(Button)findViewById(R.id.button3);
        reg.setOnClickListener(this);
        clr.setOnClickListener(this);
        this.sv=new SignatureView(this);
        v.addView(sv);
       
        
    }
    public void clear()
    {
		/* this.sv.paint.setAntiAlias(true);
		 this.sv.paint.setColor(Color.BLACK);
		 this.sv.paint.setStyle(Paint.Style.STROKE);
		 this.sv.paint.setStrokeJoin(Paint.Join.ROUND);
		 this.sv.paint.setStrokeWidth(this.sv.STROKE_WIDTH);
	     Bitmap signatureBitmap = Bitmap.createBitmap(this.sv.layw, this.sv.layh, Bitmap.Config.RGB_565);
	     Canvas canvas = new Canvas(signatureBitmap);
	     this.sv.draw(canvas);*/
    	this.sv.invalidate();
		 
    }
	@Override
	public void onClick(View arg0) {
			switch(arg0.getId())
			{
			case R.id.but:
	            SQLiteDatabase db=this.openOrCreateDatabase("mydb.db", MODE_PRIVATE, null);
	            db.execSQL("CREATE TABLE IF NOT EXISTS yas(fx integer,fy integer);");
	            Cursor cc=null;
	            try
	            {
	            cc=db.rawQuery("select fx,fy from yas",null);
	            if(cc.moveToNext())
	            {
		            Toast.makeText(MainActivity2.this, "table has values"+cc.getFloat(0)+cc.getFloat(1), Toast.LENGTH_LONG).show();

	            	db.execSQL("DROP TABLE yas");
	            }
	            else
	            {
		            Toast.makeText(MainActivity2.this, "inserting"+historySize, Toast.LENGTH_LONG).show();
	            for(int i=0;i<historySize;i++)
	            {
	            	db.execSQL("INSERT INTO yas (fx,fy) VALUES ("+(int)findx[i]+","+findy[i]+")");
		            Toast.makeText(MainActivity2.this, "inserted succesfully", Toast.LENGTH_LONG).show();
	            }
	            historySize=0;
	            cc.close();
	      
	            db.close();
	            Toast.makeText(MainActivity2.this, "successfully saved", Toast.LENGTH_LONG).show();
	            }}
	            catch(Exception e)
	            {
	            	Toast.makeText(MainActivity2.this, e.toString(), Toast.LENGTH_LONG).show();
	            }
	            break;
	           
			
				 
	 
			case R.id.button3:
	        	
	 this.sv.clearSignature();
	 break;
	 default:
		 break;
	}
	        
	  
	}
    
class SignatureView extends View {
	 
    // set the stroke width
    static final float STROKE_WIDTH = 5f;
    private static final float HALF_STROKE_WIDTH = STROKE_WIDTH / 2;

    Paint paint = new Paint();
    private Path path = new Path();

    private float lastTouchX;
    private float lastTouchY;
    public int layh;
    public int layw;
    private final RectF dirtyRect = new RectF();

    public SignatureView(Context context) {

        super(context);

        paint.setAntiAlias(true);
        paint.setColor(Color.BLACK);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeJoin(Paint.Join.ROUND);
        paint.setStrokeWidth(STROKE_WIDTH);

        // set the bg color as white
        this.setBackgroundColor(Color.WHITE);

        // width and height should cover the screen
        this.setLayoutParams(new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        layw=this.getWidth();
        layh=this.getHeight();
    }

    /**
     * Get signature
     *
     * @return
     */
    protected Bitmap getSignature() {

        Bitmap signatureBitmap = null;

        // set the signature bitmap
        if (signatureBitmap == null) {
            signatureBitmap = Bitmap.createBitmap(this.getWidth(), this.getHeight(), Bitmap.Config.RGB_565);
        }

        // important for saving signature
        final Canvas canvas = new Canvas(signatureBitmap);
        this.draw(canvas);
        return signatureBitmap;
    }

    /**
     * clear signature canvas
     */
    private void clearSignature() {
        this.invalidate();
        this.path=new Path();
    }

    // all touch events during the drawing
    @Override
    protected void onDraw(Canvas canvas) {
        canvas.drawPath(this.path, this.paint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float eventX = event.getX();
        float eventY = event.getY();

        switch (event.getAction()) {
        case MotionEvent.ACTION_DOWN:

            path.moveTo(eventX, eventY);

            lastTouchX = eventX;
            lastTouchY = eventY;
            return true;

        case MotionEvent.ACTION_MOVE:

        case MotionEvent.ACTION_UP:

            resetDirtyRect(eventX, eventY);
            MainActivity2.historySize = event.getHistorySize();
            for (int i = 0; i <  MainActivity2.historySize-1; i++) {
                float historicalX = event.getHistoricalX(i);
                float historicalY = event.getHistoricalY(i);
                if(i< MainActivity2.historySize)
                {
                	 MainActivity2.findx[i]=(int) (historicalX-event.getHistoricalX(i+1));
                	 MainActivity2.findy[i]=(int) (historicalY-event.getHistoricalY(i+1));
                }
                expandDirtyRect(historicalX, historicalY);
                path.lineTo(historicalX, historicalY);
            }
            path.lineTo(eventX, eventY);
            break;

        default:

            return false;
        }

        invalidate((int) (dirtyRect.left - HALF_STROKE_WIDTH),
                (int) (dirtyRect.top - HALF_STROKE_WIDTH),
                (int) (dirtyRect.right + HALF_STROKE_WIDTH),
                (int) (dirtyRect.bottom + HALF_STROKE_WIDTH));

        lastTouchX = eventX;
        lastTouchY = eventY;

        return true;
    }

    private void expandDirtyRect(float historicalX, float historicalY) {
        if (historicalX < dirtyRect.left) {
            dirtyRect.left = historicalX;
        } else if (historicalX > dirtyRect.right) {
            dirtyRect.right = historicalX;
        }

        if (historicalY < dirtyRect.top) {
            dirtyRect.top = historicalY;
        } else if (historicalY > dirtyRect.bottom) {
            dirtyRect.bottom = historicalY;
        }
    }

    private void resetDirtyRect(float eventX, float eventY) {
        dirtyRect.left = Math.min(lastTouchX, eventX);
        dirtyRect.right = Math.max(lastTouchX, eventX);
        dirtyRect.top = Math.min(lastTouchY, eventY);
        dirtyRect.bottom = Math.max(lastTouchY, eventY);
    }

}
}

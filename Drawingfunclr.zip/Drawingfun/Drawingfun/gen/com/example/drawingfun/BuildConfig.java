/** Automatically generated file. DO NOT MODIFY */
package com.example.drawingfun;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}